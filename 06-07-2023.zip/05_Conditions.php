<!-- Conditions in php -->

<?php
// Example 1: if-else condition
$age = 25;

if ($age >= 18) {
    echo "You are eligible to vote.<br>";
} else {
    echo "You are not eligible to vote.<br>";
}

// Example 2: if-elseif-else condition
$score = 85;

if ($score >= 90) {
    echo "Your grade is A.<br>";
} elseif ($score >= 80) {
    echo "Your grade is B.<br>";
} elseif ($score >= 70) {
    echo "Your grade is C.<br>";
} else {
    echo "Your grade is D.<br>";
}

// Example 3: switch condition
$dayOfWeek = 3;

switch ($dayOfWeek) {
    case 1:
        echo "Today is Monday.<br>";
        break;
    case 2:
        echo "Today is Tuesday.<br>";
        break;
    case 3:
        echo "Today is Wednesday.<br>";
        break;
    case 4:
        echo "Today is Thursday.<br>";
        break;
    case 5:
        echo "Today is Friday.<br>";
        break;
    default:
        echo "Today is a weekend day.<br>";
        break;
}

// Example 4: ternary operator
$isRaining = true;

$weatherStatus = ($isRaining) ? "It's raining." : "It's not raining.";
echo $weatherStatus . "<br>";
?>
