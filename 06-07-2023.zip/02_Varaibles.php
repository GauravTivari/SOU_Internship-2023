<!-- Variables in php -->

<?php
// Variable declaration and assignment
$fname = "Abc";
$lname = "Xyz";
$country = "India";

// Output the values of variables
echo "First Name: " . $fname . "<br>";
echo "Last Name: " . $lname . "<br>";
echo "Country: " . $country . "<br>";


// Variable reassignment
$fname = "Pqr";
echo "New name: " . $fname . "<br>";
?>
