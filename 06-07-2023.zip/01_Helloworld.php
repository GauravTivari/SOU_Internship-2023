<!-- Hello World in php -->

<?php
echo "Hello World..!!"
?>