<!-- Loops in php -->

<?php
// Example 1: for loop
for ($i = 1; $i <= 5; $i++) {
    echo  $i . "<br>";
}

// Example 2: while loop
$j = 1;
while ($j <= 5) {
    echo $j . "<br>";
    $j++;
}

// Example 3: do-while loop
$k = 1;
do {
    echo  $k . "<br>";
    $k++;
} while ($k <= 5);

// Example 4: foreach loop
$fruits = array("Apple", "Banana", "Orange", "Mango");

foreach ($fruits as $fruit) {
    echo $fruit . "<br>";
}

// Example 5: nested loops
for ($row = 1; $row <= 3; $row++) {
    for ($col = 1; $col <= 3; $col++) {
        echo "Row: " . $row . ", Column: " . $col . "<br>";
    }
}
?>
