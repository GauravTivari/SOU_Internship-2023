<!-- Operators in php -->

<?php
// Arithmetic operators
$num1 = 10;
$num2 = 5;

$sum = $num1 + $num2;
$diff = $num1 - $num2;
$product = $num1 * $num2;
$quotient = $num1 / $num2;
$remainder = $num1 % $num2;

echo "Sum: " . $sum . "<br>";
echo "Difference: " . $diff . "<br>";
echo "Product: " . $product . "<br>";
echo "Quotient: " . $quotient . "<br>";
echo "Remainder: " . $remainder . "<br>";

// Assignment operators
$num3 = 15;
$num3 += 5; // Equivalent to $num3 = $num3 + 5
$num3 -= 3; // Equivalent to $num3 = $num3 - 3
$num3 *= 2; // Equivalent to $num3 = $num3 * 2
$num3 /= 4; // Equivalent to $num3 = $num3 / 4
$num3 %= 3; // Equivalent to $num3 = $num3 % 3

echo "Updated num: " . $num3 . "<br>";

// Comparison operators
$num4 = 20;
$num5 = 30;

$equal = $num4 == $num5;
$notEqual = $num4 != $num5;
$greaterThan = $num4 > $num5;
$lessThan = $num4 < $num5;
$greaterThanOrEqual = $num4 >= $num5;
$lessThanOrEqual = $num4 <= $num5;

echo "Equal: " . $equal . "<br>";
echo "Not Equal: " . $notEqual . "<br>";
echo "Greater Than: " . $greaterThan . "<br>";
echo "Less Than: " . $lessThan . "<br>";
echo "Greater Than or Equal: " . $greaterThanOrEqual . "<br>";
echo "Less Than or Equal: " . $lessThanOrEqual . "<br>";

// Logical operators
$condition1 = true;
$condition2 = false;

$andResult = $condition1 && $condition2;
$orResult = $condition1 || $condition2;
$notResult = !$condition1;

echo "AND Result: " . $andResult . "<br>";
echo "OR Result: " . $orResult . "<br>";
echo "NOT Result: " . $notResult . "<br>";

// String concatenation operator
$name1 = "Abc";
$name2 = "Xyz";

$fullName = $name1 . " " . $name2;
echo "Full Name: " . $fullName . "<br>";
?>
