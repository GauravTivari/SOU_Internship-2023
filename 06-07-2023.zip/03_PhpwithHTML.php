<!-- php program with html. -->

<!DOCTYPE html>
<html>
<head>
    <title>PHP with HTML Example</title>
</head>
<body>
    <h1>Welcome to PHP with HTML Example</h1>
    
    <?php
    // PHP code starts here
    $fname = "Abc";
    $lname = "Xyz";
    $country = "India";
    
    echo "<h3>First Name: $fname</h3>";
    echo "<h3>Last Name: $lname</h3>";
    echo "<h3>Country: $country</h3>";
    ?>
    
</body>
</html>
