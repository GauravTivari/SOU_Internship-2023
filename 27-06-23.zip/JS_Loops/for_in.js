const Human = {FirstName:"Gaurav", LastName:"Tivari", age:25};
for (let H in Human) {
    document.write("<br/>"+H);
  }
document.write("<hr/>");
for (let H in Human) {
  document.write("<br/>"+Human[H]);
}