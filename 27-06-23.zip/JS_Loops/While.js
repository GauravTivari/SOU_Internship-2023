let i=0;
while (i < 10) {
    document.write("<br/>"+i);
    i++;
  }