let i=0;
do{
  document.write("<br/>"+i);
  i++;
}
while (i < 10);