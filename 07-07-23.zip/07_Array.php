<?php
// Example 1: Numeric array
$fruits = array("Apple", "Banana", "Orange", "Mango");

// Accessing array elements
echo "First fruit: " . $fruits[0] . "<br>";
echo "Second fruit: " . $fruits[1] . "<br>";

// Modifying array element
$fruits[2] = "Grapes";
echo "Updated third fruit: " . $fruits[2] . "<br>";

// Adding elements to the array
$fruits[] = "Pineapple";
echo "Added fruit: " . $fruits[4] . "<br>";

// Example 2: Associative array
$person = array(
    "name" => "Gaurav Tivari",
    "country" => "India"
);

// Accessing array elements
echo "Name: " . $person["name"] . "<br>";
echo "Country: " . $person["country"] . "<br>";

// Example 3: Multidimensional array
$students = array(
    array("John", "Doe", 25),
    array("Jane", "Smith", 22),
    array("David", "Johnson", 28)
);

// Accessing array elements
echo "Name: " . $students[0][0] . " " . $students[1][1] . "<br>";
echo "Age: " . $students[1][2] . "<br>";
?>
