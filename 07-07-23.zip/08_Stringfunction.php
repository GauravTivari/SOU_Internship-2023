<?php
// Example 1: strlen() - Returns the length of a string
$string = "Hello, world!";
$length = strlen($string);
echo "Length of the string: " . $length . "<br>";

// Example 2: strtoupper() - Converts a string to uppercase
$string = "hello, world!";
$uppercase = strtoupper($string);
echo "Uppercase string: " . $uppercase . "<br>";

// Example 3: strtolower() - Converts a string to lowercase
$string = "HELLO, WORLD!";
$lowercase = strtolower($string);
echo "Lowercase string: " . $lowercase . "<br>";

// Example 4: substr() - Extracts a substring from a string
$string = "Hello, world!";
$substring = substr($string, 7, 5);
echo "Substring: " . $substring . "<br>";

// Example 5: str_replace() - Replaces all occurrences of a substring within a string
$string = "Hello, world!";
$newString = str_replace("world", "PHP", $string);
echo "New string: " . $newString . "<br>";

// Example 6: strpos() - Finds the position of the first occurrence of a substring within a string
$string = "Hello, world!";
$position = strpos($string, "world");
echo "Position of 'world': " . $position . "<br>";
?>
