
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textuname.Text = "";
            textmobileno.Text = "";
            textemail.Text = "";
            comborating.SelectedIndex = 0;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           


            comborating.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
          string connectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\admin\\Documents\\mydemo.mdf;" +
                "Integrated Security=True;Connect Timeout=30";

          SqlConnection con = new SqlConnection(connectionstring);
          con.Open();
          string query = "insert into [Table](id,username,mobileno,email,rating) values('5','"+textuname.Text +"','"+textmobileno.Text+"'," +
                "'"+textemail.Text+"','"+comborating.Text+"')";
          SqlCommand sqlCommand = new SqlCommand(query, con);
          sqlCommand.ExecuteNonQuery();
          con.Close();
          MessageBox.Show("record inserted !");

        }
    }
}