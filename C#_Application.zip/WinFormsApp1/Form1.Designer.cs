﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textuname = new TextBox();
            textmobileno = new TextBox();
            textemail = new TextBox();
            comborating = new ComboBox();
            label4 = new Label();
            label5 = new Label();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 56);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(88, 21);
            label1.TabIndex = 0;
            label1.Text = "User Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 114);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(83, 21);
            label2.TabIndex = 1;
            label2.Text = "Mobile No";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 163);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(48, 21);
            label3.TabIndex = 2;
            label3.Text = "Email";
            // 
            // textuname
            // 
            textuname.Location = new Point(168, 53);
            textuname.Margin = new Padding(4);
            textuname.Name = "textuname";
            textuname.Size = new Size(270, 29);
            textuname.TabIndex = 3;
            // 
            // textmobileno
            // 
            textmobileno.Location = new Point(171, 104);
            textmobileno.Margin = new Padding(4);
            textmobileno.Name = "textmobileno";
            textmobileno.Size = new Size(165, 29);
            textmobileno.TabIndex = 4;
            // 
            // textemail
            // 
            textemail.Location = new Point(171, 160);
            textemail.Margin = new Padding(4);
            textemail.Name = "textemail";
            textemail.Size = new Size(268, 29);
            textemail.TabIndex = 5;
            // 
            // comborating
            // 
            comborating.FormattingEnabled = true;
            comborating.Items.AddRange(new object[] { "1", "2", "3", "4", "5" });
            comborating.Location = new Point(168, 211);
            comborating.Margin = new Padding(4);
            comborating.Name = "comborating";
            comborating.Size = new Size(154, 29);
            comborating.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(8, 215);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(142, 21);
            label4.TabIndex = 7;
            label4.Text = "Give Rating 1 to 5  ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(127, 9);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(209, 21);
            label5.TabIndex = 8;
            label5.Text = "FeedBack Form on Lecture";
            // 
            // button1
            // 
            button1.Location = new Point(75, 326);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(96, 32);
            button1.TabIndex = 9;
            button1.Text = "Save";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(291, 326);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(96, 32);
            button2.TabIndex = 10;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(451, 368);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(comborating);
            Controls.Add(textemail);
            Controls.Add(textmobileno);
            Controls.Add(textuname);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(4);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            Text = "Feeback Form";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textuname;
        private TextBox textmobileno;
        private TextBox textemail;
        private ComboBox comborating;
        private Label label4;
        private Label label5;
        private Button button1;
        private Button button2;
    }
}