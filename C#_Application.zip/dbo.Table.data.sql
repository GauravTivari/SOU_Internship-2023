﻿INSERT INTO [dbo].[Table] ([Id], [username], [mobileno], [email], [rating]) VALUES (1, N'raviraj', N'9999999', N'one@one.com', CAST(3 AS Decimal(18, 0)))
INSERT INTO [dbo].[Table] ([Id], [username], [mobileno], [email], [rating]) VALUES (2, N'ronak', N'989898', N'two@two.com', CAST(4 AS Decimal(18, 0)))
