<?php
require '01_db_connection.php';

if(isset($_POST["Submit"])){
    $Name = $_POST["Name"];
    $Username = $_POST["Username"];
    $Age = $_POST["Age"];
    $Gender = $_POST["Gender"];
    $Password = $_POST["Password"];

    $query = "INSERT INTO demo_insert VALUES('$Name','$Username','$Age','$Gender','$Password')";
    mysqli_query($conn,$query);
    echo
    "
    <script>alert('Data inserted successfully')</script>
    ";
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form class="" action="" method="post" autocomplete="off">
        <lable for=""> Name</label>
        <input type="text" name="Name" required value="">
        <lable for=""> Username</label>
        <input type="text" name="Username" required value="">
        <lable for=""> Age</label>
        <input type="number" name="Age" required value="">
        <lable for=""> Gender</label>
        <input type="radio" name="Gender" value="Male" required value=""> Male
        <input type="radio" name="Gender" value="Female" required value=""> Female
        <lable for=""> Password</label>
        <input type="password" name="Password" required value="">
        <input type="submit" name="Submit" required value="Submit">
    </form>
</body>
</html>